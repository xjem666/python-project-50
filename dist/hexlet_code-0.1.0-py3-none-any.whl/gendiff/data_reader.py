def read_data(file_path):
    return open(file_path)


def define_extension(file_path):
    return file_path.split('.')[1]
